package mediaRentalManager;

import java.util.ArrayList;
import java.util.Collections;



public class MediaRentalManager implements MediaRentalManagerInt {
	//should behave as a queue??
	private  ArrayList<Customer> customers = new ArrayList<Customer>(); 
	//due to polymorphism we can fill this media array with movie objects and album objects
	//should behave as a queue??
	private  ArrayList<Media> media = new ArrayList<Media>();

	//searches the media arraylist for the users input and returns the Media object with the correct title
	private int findCopiesAvailable(String title) {
		int copiesAvailable=0;
		//go through media arraylist returning the title of each object, if we find a matching title, evaluate
		//that media objects copies available and return that value
		for (int i = 0; i < media.size(); i++) {

			if (title.equals(media.get(i).getTitle())) {
				copiesAvailable = media.get(i).getCopiesAvailable();
			} 
		} return copiesAvailable;

	}
	private void oneLessCopyAvailable(String title) {

		//go through media arraylist returning the title of each object, if we find a matching title, 
		//subtract 1 from its available copies
		for (int i = 0; i < media.size(); i++) {

			if (title.equals(media.get(i).getTitle())) {
				media.get(i).oneLessCopyAvailable();
			} 
		} 

	}


	@Override
	//Adds the specified customer to the database. The address is a physical address (not e-mail).
	//The plan options available are: <b>LIMITED</b> and <b>UNLIMITED</b>.  LIMITED 
	//defines a default maximum of two media that can be rented.
	public void addCustomer(String name, String address, String plan) {
		//create a customer object from input, and pass that object into customer database
		Customer customer = new Customer(name, address, plan);
		//if the customer is not already in the customer database add them
		//loop through customers searching and comparing to make sure it isnt already there
		for (int i=0; i < customers.size(); i++) {
			if(customer.equals(customers.get(i))==true) {
				return;

			}
		}
		customers.add(customer);
		Collections.sort(customers);

	}


	@Override
	//Adds the specified movie to the database. The possible values for rating are
	//"PG", "R", "NR".
	public void addMovie(String title, int copiesAvailable, String rating) {
		//create a movie object from input and pass that object into database that holds movies annd albums
		Movie movie = new Movie(title, copiesAvailable, rating);
		for (int i=0; i < media.size(); i++) {
			if(movie.equals(media.get(i))==true) {
				return;

			}
		}
		Collections.sort(media);
		media.add(movie);
	}

	//Adds the specified album to the database. The songs String includes
	//a list of the title of songs in the album (song titles are separated by
	//commas).
	@Override
	public void addAlbum(String title, int copiesAvailable, String artist, 
			String songs) {
		//create a album object from input and pass that object into database that holds movies annd albums
		Album album = new Album(title, copiesAvailable, artist, songs);
		for (int i=0; i < media.size(); i++) {
			if(album.equals(media.get(i))==true) {
				return;

			}
		}
		Collections.sort(media);
		media.add(album);
	}

	@Override	
	//we can either make customer limit static and set the static limit
	//or make customer limit instance and loop through every customer in
	//customer array and set each customers limit if hasLimit == true.. which 
	//would be better?

	//if a customer has a limited plan, set that limit
	//this should apply to all customers of the LIMITED plan

	//This set the number of media associated with the LIMITED plan.

	public void setLimitedPlanLimit(int value) {
		//if customer plan == LIMITED then set limit to input or just set it since we have code in customer class where it wouldnt effect unlimited customers ?
		Customer.setLimit(value);
	}

	//Returns information about the customers in the database.  The information is
	// presented sorted by customer name.  See the public tests for the format
	// to use.
	@Override
	public String getAllCustomersInfo() {
		//loop through every customer in customers array and add their string to 
		//all info, then return it
		String allInfo = "***** Customers' Information *****\n";
		//sort before looping
		for (int i=0; i<this.customers.size(); i++) {
			allInfo += customers.get(i).toString();
			allInfo += "\n";
		}
		return allInfo;

	}

	//Returns information about all the media (movies and albums) that are part
	// of the database.  The information is presented sorted by media title.  See
	// the public tests for the format to use.
	@Override
	public String getAllMediaInfo() {
		String allInfo = "***** Media Information *****\n";
		//sort before looping
		Collections.sort(media);

		for (int i=0; i<this.media.size(); i++) {
			allInfo += media.get(i).toString();
			allInfo += "\n";
		}
		return allInfo;
	}

	//Adds the specified media title to the queue associated with a customer. If it finds the customer it adds to their queue then returns true
	//if it cant find the customer it does nothing and returns false
	@Override
	public boolean addToQueue(String customerName, String mediaTitle) {
		for (int i=0; i<customers.size(); i++) {
			//loop through customer database evaluating every customer object for its name, if we find it then add mediaTitle to its queue
			if(customers.get(i).getName().equals(customerName)) {
				customers.get(i).addQueue(mediaTitle);
				return true;
			}
		}
		return false;
	}

	//Removes the specified media title from the customer's queue.
	@Override
	public boolean removeFromQueue(String customerName, String mediaTitle) {
		for (int i=0; i<customers.size(); i++) {
			//loop through customer database evaluating every customer object for its name, if we find it then remove mediaTitle to its queue
			if(customers.get(i).getName().equals(customerName)) {
				customers.get(i).removeQueue(mediaTitle);
				return true;
			}
		}
		return false;
	}
	/*
	 * Processes the requests queue of each customer.  The customers will be processed
	 * in alphabetical order.  For each customer, the requests queue will be checked
	 * and media will be added to the rented queue, if the plan associated with 
	 * the customer allows it, and if there is a copy of the media available.
	 * For UNLIMITED plans the media will be added to the rented queue always,
	 * as long as there are copies associated with the media available.  For
	 * LIMITED plans, the number of entries moved from the requests queue to the rented
	 * queue will depend on the number of currently rented media, and whether
	 * copies associated with the media are available.<br>
	 * <br> 
	 * For each media that is rented, the following message will be generated:<br>
	 * "Sending [mediaTitle] to [customerName]" <br>
	 * 
	 * @return 
	 */
	//first sort the customers arraylist alphabetically
	//if get.copiesAvailable evaluates >1, setCopiesAvailable to copiesAvailable--
	//then remove the first value from the wants queue (.remove(0) ) and add it to the end of rented queue (.add)
	//if the add returns true (succesful) concatenate it to the all succesful message and finally return the all successful messages
	//for each customer in customers arraylist, remove the first value in the wants queue and add that value to the end of has queue, keeping the limit in mind
	//the mediaRentalManager methods can help reduce code redundancy
	@Override
	public String processRequests() {
		String actionTaken = "";
		//sort customers alphabetically
		Collections.sort(customers);
		//For each customer, the requests queue will be checked
		//and media will be added to the rented queue, if the plan associated with 
		//the customer allows it, and if there is a copy of the media available.
		for (int databaseIndex=0; databaseIndex<customers.size();
				databaseIndex++) {
			//store the current customer in a variable named thisCustomer to improve readability
			Customer thisCustomer = customers.get(databaseIndex);
			//store request Queue size to a variable since removing its values will shrink the number of iterations. 
			//we don't want the number of iterations to shrink with each removal
			int requestSize = customers.get(databaseIndex).getQueue().size();
			for (int requestIndex=0; requestIndex<requestSize; requestIndex++)
				//if the requestQueue has stuff in it, take stuff out of it and put it in the rentalQue, using FIFO principle
				//AND also make sure there are copies available, in media database, subtracting a copy every time we add to rented
				//we cant store these conditionals in a variable for readability because they need to be dynamic
				//AND if the limit is less than or equal to size of rented
				if((customers.get(databaseIndex).getQueue().size() >= 1)) {
					
					if((customers.get(databaseIndex).getPlan().equals("LIMITED") && customers.get(databaseIndex).getRented().size() >= Customer.getLimit()) || 
					(findCopiesAvailable(customers.get(databaseIndex).getQueue().get(0)) == 0)) {
							//if theyve passed their limit or if the current queues first item is less than 0 do nothing
					} else {
						//if both evaluate to true update database by subtracting a copy
						oneLessCopyAvailable(customers.get(databaseIndex).getQueue().get(0));

						customers.get(databaseIndex);
						//System.out.println(findCopiesAvailable(customers.get(databaseIndex).getQueue().get(0))); //del this. it just shows that a copy was subtracted
						//For each media that is rented, the following message will be generated:
						//"Sending [mediaTitle] to [customerName]" 

						String removed = customers.get(databaseIndex).getQueue().
								remove(0);
						customers.get(databaseIndex).addRented(removed);

						actionTaken+="Sending "+removed+" to "+
								thisCustomer.getName()+"\n";
					}
				}
		}

		return actionTaken;
	}

	/*
	 * This is how a customer returns a rented media.  This method will remove the item
	 * from the rented queue and adjust any other values that are necessary (e.g., copiesAvailable)
	 * @param customerName
	 * @param mediaTitle
	 * @return
	 */
	@Override
	public boolean returnMedia(String customerName, String mediaTitle) {
		boolean found = false;
		//search through customers database for customer with that name. 
		for (int i = 0 ; i < customers.size(); i ++) {
			if (customers.get(i).getName().equals(customerName)) {
				Customer currentCustomer = customers.get(i);
				ArrayList<String> currentCustomersRentals = currentCustomer.getRented();
				for (int j = 0; j < currentCustomersRentals.size(); j ++) {
					if (currentCustomersRentals.get(j).equals(mediaTitle)) {
						found = true;
						currentCustomersRentals.remove(j);
					}
				}
			}
		}
	
		//if the customers name is found, search through their rented queue for media with that title
		//if the media is found, remove it from their rental queue
		//once the rental is removed from their rental queue, search media database for media with that title
		if (found == true) {
			for (int i = 0 ; i < media.size(); i ++) {
				if (media.get(i).getTitle().equals(mediaTitle)) {
					//if that media title is found in database, increase copies available of that object by 1
					media.get(i).oneMoreCopyAvailable();
				}
			}
		}
		
		return found;
	}
	/**
	 * Returns a SORTED ArrayList with media titles that satisfy the provided parameter values.
	 * If null is specified for a parameter, then that parameter should be ignore in the
	 * search.  Providing null for all parameters will return all media titles.
	 * @param title
	 * @param rating
	 * @param artist
	 * @param songs
	 * @return
	 */
	@Override
	public ArrayList<String> searchMedia(String title, String rating,
			String artist, String songs) {
	
		//create a "results found" media arraylist
		ArrayList<String> found =  new ArrayList<String>();
		//Providing null for all parameters will return all media titles
		if(title==null && rating==null && artist==null && songs==null) {
			for (int i = 0 ; i < media.size(); i ++) {
				found.add(media.get(i).getTitle());
			}
			Collections.sort(found);
			return found;
			
		}
		
		//search through media database for media.getTitle, if found add media.getTitle() to results
		for (int i = 0 ; i < media.size(); i ++) {
			if(media.get(i).getTitle().equals(title)) {
				found.add(media.get(i).getTitle());
			}
		}
		//search through media database for media.getRating, if found add media.getTitle() to results
		for (int i = 0 ; i < media.size(); i ++) {
			if(media.get(i).getRating().equals(rating)) {
				found.add(media.get(i).getTitle());
				
			}
		}
		//search through media database for media.getArtist, if found add media.getTitle() to results
		for (int i = 0 ; i < media.size(); i ++) {
			if(media.get(i).getArtist().equals(artist)) {
				found.add(media.get(i).getTitle());
			}
		}
		//search through media database for media.getSongs, if found add media.getTitle() to results
		//Regarding the searchMedia method: the songs parameter represents a substring (fragment) or 
		//the full list of songs associated with the album. If the full list is provided, you can assume 
		//commas will be part of the string. Hint: you may want to consider using the indexOf method of the 
		//String class.
		for (int i = 0 ; i < media.size(); i ++) {
			//if the medias song is the same as input or at least contrains it, add the title to the found list
			if(media.get(i).getSongs().equals(songs) ) {
				found.add(media.get(i).getTitle());
			} 
		}
		
	
		//sort media array
		//return the array
		
		//remove duplicate code below
		//Set<String> set = new HashSet<>(found);
		//found.clear();
		//found.addAll(set);
		
		Collections.sort(found);
		return found;
	}
	public static void main(String[] args) {

		MediaRentalManager manager = new MediaRentalManager();
		Customer.setLimit(2);

		manager.addAlbum("B1 album", 999, "LetterGod","Tracks of B1");
		manager.addAlbum("B2 album", 2, "LetterGod","Tracks of B2");
		manager.addAlbum("B3 album", 2, "LetterGod", "Mirror, Far Away");
		manager.addAlbum("B4 album", 0, "Zezima","Tracks 1,2,3,4,5");

		manager.addCustomer("B", "home", "limited");
		manager.addCustomer("C", "home", "unlimited");
		manager.addCustomer("A", "home", "unlimited");

		manager.addToQueue("B","B1 album");
		manager.addToQueue("B","B2 album");
		manager.addToQueue("B","B3 album");
		manager.addToQueue("B","B4 album");

		manager.addToQueue("C","C1 album");
		manager.addToQueue("C","C2 album");
		manager.addToQueue("C","C3 album");
		manager.addToQueue("C","C4 album");

		manager.addToQueue("A","A1 album");
		manager.addToQueue("A","A2 album");
		manager.addToQueue("A","A3 album");
		manager.addToQueue("A","A4 album");
		
		System.out.println(manager.searchMedia("B1 album", null, "LetterGod", "Far Away"));
		System.out.println(manager.searchMedia(null, null, null, null));
		
		//String WholeString = "Mirror, Far Away";
		//System.out.println(WholeString.indexOf("Far Away"));
		//System.out.println(WholeString.contains("Far way"));

		//System.out.println(customers);


		//System.out.println(manager.processRequests());
		//System.out.println(customers);
		//System.out.println(manager.getAllCustomersInfo());

		//manager.addMovie("The Dark Knight", 999, "9.1");
		//System.out.println(media);
		//System.out.println(manager.getAllMediaInfo());
		//System.out.println(manager.findCopiesAvailable("The Dark Knight"));

		//System.out.println(media.get(0));	
		//System.out.println(media.get(0).getTitle());
		//manager.addMovie("Harry Potter", 2, "10");
		//manager.addAlbum("A1 album", 2, "Mozart", "Classical1, Classical2, Classical3");
		//System.out.println(manager.findCopiesAvailable("A1 album"));;

		//Customer customer1 = new Customer("B", "home", "unlimited");
		//Customer customer2 = new Customer("C", "home", "unlimited");
		//Customer customer3 = new Customer("A", "home", "unlimited");
		//customer1.addQueue("B album");
		//customer2.addQueue("C album");
		//customer3.addQueue("A album");
		//customers.add(customer1);
		//	customers.add(customer2);
		//customers.add(customer3);




		/*
		manager.addCustomer("Ndenko","12620 Hillmeade Station Dr", "unlimited");
		manager.addCustomer("Batman","Gotham", "limited");
		manager.addCustomer("Netero","Mountains", "limited");
		System.out.println(manager.getAllCustomersInfo());
		manager.addAlbum("MOTM 3", 999, "Kid Cudi", "motm3, tequila shots, dive");
		manager.addMovie("The Dark Knight", 999, "9.1");
		System.out.println(manager.getAllMediaInfo());
		manager.setLimitedPlanLimit(3);
		System.out.println(Customer.getLimit());
		System.out.println(manager.addToQueue("Mom", "ColdPlay Album 3"));//should return false since mom never added
		System.out.println(manager.addToQueue("Ndenko", "ColdPlay Album 3"));//should return true since ndenko was added
		System.out.println(manager.getAllCustomersInfo());//ndenkos queue should now have values
		System.out.println(manager.removeFromQueue("Ndenko", "ColdPlay Album 3"));//should return true since ndenko was added
		System.out.println(manager.getAllCustomersInfo());//ndenkos queue should now have no values
		Collections.sort(manager.customers);
		System.out.println(manager.customers);//works
		 */
	}
}
