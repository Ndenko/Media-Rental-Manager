package mediaRentalManager;

public class Movie extends Media {
	/**Instance variables for Movie
	 * 
	 */
	String title = "";
	int copiesAvailable = 0;
	String rating = "";
	/**Constructor for media movies
	 * 
	 * @param title
	 * @param copiesAvailable
	 * @param rating
	 */
	public Movie(String title, int copiesAvailable, String rating) {
		super(title, copiesAvailable, rating);
		// TODO Auto-generated constructor stub
	}



	/**Gets media title
	 * 
	 * @return returns media title as string
	 */
	public String getTitle() {
		return super.title;
	}
	/**Gets copies left
	 * 
	 * @return returns an integer of the copies left
	 */
	public int getCopiesAvailable() {
		return super.copiesAvailable;
	}
	/**Gets media rating
	 * 
	 * @return returns media rating as string
	 */
	public String getRating() {
		return super.rating;
	}
	/**Subtracts 1 copy from total
	 * 
	 */
	public void oneLessCopyAvailable() {
		super.copiesAvailable--;
	}
	/**Adds copy to total
	 * 
	 */
	public void oneMoreCopyAvailable() {
		super.copiesAvailable++;
	}
	/**Describes the object in String
	 * 
	 */
	public String toString() {
		return "Title: "+super.title+", Copies Available: "+
				super.copiesAvailable+", Rating: "+super.rating;
	}
	public static void main(String[] args) {
		Media movie = new Media("Harry Potter", 2, "10");
		System.out.println(movie);
	}
}
