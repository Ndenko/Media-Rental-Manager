package mediaRentalManager;

public class Album extends Media {
	/**Instance variables for Album
	 * 
	 */
	String title = "";
	int copiesAvailable = 0;
	String artist = "";
	String songs = "";
	/**Constructor for media albums
	 * 
	 * @param title
	 * @param copiesAvailable
	 * @param artist
	 * @param songs
	 */
	public Album(String title, int copiesAvailable, String artist, String songs)
	{
		super(title, copiesAvailable, artist, songs);
	
	}


	/**Gets media title
	 * 
	 * @return returns media title as string
	 */
	public String getTitle() {
		return super.title;
	}
	/**Gets copies left
	 * 
	 * @return returns an integer of the copies left
	 */
	public int getCopiesAvailable() {
		return super.copiesAvailable;
	}
	/**Gets media artist
	 * 
	 * @return returns media artist as string
	 */
	public String getArtist() {
		return super.artist;
	}
	/**Gets media songs
	 * 
	 * @return returns media songs as string
	 */
	public String getSongs() {
		return super.songs;
	}
	/**Subtracts 1 copy from total
	 * 
	 */
	public void oneLessCopyAvailable() {
		super.copiesAvailable--;
	}
	/**Adds copy to total
	 * 
	 */
	public void oneMoreCopyAvailable() {
		super.copiesAvailable++;
	}
	/**Describes the object in String
	 * 
	 */
	public String toString() {
		return "Title: "+super.title+", Copies Available: "+
				super.copiesAvailable
				+", Artist: "+super.artist+", Songs: "+super.songs;
	}
	public static void main(String[] args) {
		Media album = new Media("A1 album", 2, "Mozart", "Classical1, "
				+ "Classical2, Classical3");
		System.out.println(album.toString());
		System.out.println(album.getTitle());
	}
}
