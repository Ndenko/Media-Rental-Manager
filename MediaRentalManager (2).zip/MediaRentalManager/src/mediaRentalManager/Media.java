package mediaRentalManager;
//parent class to Movie and Album, allowing for polymorphism
public class Media implements Comparable<Media>{

	/**Instance variables for Media
	 * 
	 */
	String title = "";
	int copiesAvailable = 0;
	String rating = "";

	String artist = "";
	String songs = "";

	/**Constructor for media movies
	 * 
	 * @param title
	 * @param copiesAvailable
	 * @param rating
	 */
	public Media(String title, int copiesAvailable, String rating) {
		this.title = title;
		this.copiesAvailable = copiesAvailable;
		this.rating = rating;
	}

	/**Constructor for media albums
	 * 
	 * @param title
	 * @param copiesAvailable
	 * @param artist
	 * @param songs
	 */
	public Media(String title, int copiesAvailable, String artist, String songs) 
	{
		this.title = title;
		this.copiesAvailable = copiesAvailable;
		this.artist = artist;
		this.songs = songs;
	}
	/**Gets media title
	 * 
	 * @return returns media title as string
	 */
	public String getTitle() {
		return this.title;
	}
	/**Gets media artist
	 * 
	 * @return returns media artist as string
	 */
	public String getArtist() {
		return this.artist;
	}
	/**Gets media songs
	 * 
	 * @return returns media songs as string
	 */
	public String getSongs() {
		return this.songs;
	}
	/**Gets media rating
	 * 
	 * @return returns media rating as string
	 */
	public String getRating() {
		return this.rating;
	}
	/**Gets copies left
	 * 
	 * @return returns an integer of the copies left
	 */
	public int getCopiesAvailable() {
		return this.copiesAvailable;
	}
	/**Subtracts 1 copy from total
	 * 
	 */
	public void oneLessCopyAvailable() {
		this.copiesAvailable--;
	}
	/**Adds copy to total
	 * 
	 */
	public void oneMoreCopyAvailable() {
		this.copiesAvailable++;
	}
	public boolean equals(Object obj) {
		if (obj == this) {
			return true;
		}
		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		Media media = (Media) obj;

		return title.equals(media.getTitle());
	}
	/**Allows media to be sorted
	 * 
	 */
	@Override
	public int compareTo(Media otherMedia) {
		return this.getTitle().compareToIgnoreCase(otherMedia.getTitle());

	}
	
	public static void main(String[] args) {
		Movie media = new Movie("A",1,"10");
		System.out.println(media);
		System.out.println(media.getTitle());
	}


}


