package mediaRentalManager;

import java.util.ArrayList;
import java.util.Arrays;

public class Customer implements Comparable<Customer>{

	/**Instance variables for the Customer
	 * @author Ndenko
	 */
	private String name = "";
	private String address = "";
	private String plan = "";
	private static int limit = 2;
	//holds what customer has
	private ArrayList<String> rented = new ArrayList<String>();//size set to limit
	//holds what customer wants
	private ArrayList<String> queue = new ArrayList<String>();

	/**Constructor for the customer
	 * 
	 * @param name
	 * @param address
	 * @param plan
	 */
	public Customer(String name, String address, String plan) {
		this.name = name;
		this.address = address;
		//if plan argument is not UNLIMITED or LIMITED throw error
		//call toUpper() and Trim() on argument so that user may do variety of inputs
		if(plan.toUpperCase().trim().equals("UNLIMITED") || 
				plan.toUpperCase().trim().equals("LIMITED")) {
			this.plan = plan.toUpperCase().trim();
		} else {
			throw new IllegalArgumentException("Invalid plan!");
		}
	}
	/**Sets ALL customer limits
	 * 
	 * @param limit
	 */
	public static void setLimit(int limit) {
		Customer.limit = limit;
	}
	/**Gets customer's name
	 * 
	 * @return returns customers name as string
	 */
	public String getName() {
		return this.name;
	}
	/**Get customer's address
	 * 
	 * @return returns customer's address as a string
	 */
	public String getAddress() {
		return this.address;
	}
	/**Get customer's plan
	 * 
	 * @return returns customer's plan as a string
	 */
	public String getPlan() {
		return this.plan;
	}
	/**Get customer's limit
	 * 
	 * @return returns customer's limit as an int
	 */
	public static int getLimit() {
		return Customer.limit;
	}
	/**Get customer's rental queue 
	 * 
	 * @return returns customer's rental queue
	 */
	public ArrayList<String> getRented() {
		return this.rented;
	}
	/**Get customer's wanted queue
	 * 
	 * @return returns customers wanted queue
	 */
	public ArrayList<String> getQueue() {
		return this.queue;
	}

	/**Add media title to the customer's rental queue
	 * 
	 * @param mediaTitle
	 */
	public void addRented(String mediaTitle) {
		if (this.getPlan().equals("LIMITED") && rented.size() >= 
				Customer.getLimit()) {
			return;
		} else {
			rented.add(mediaTitle);
		}
	}

	/**Add media title to the the customer's wanted queue
	 * 
	 * @param mediaTitle
	 */
	public void addQueue(String mediaTitle) {
		queue.add(mediaTitle);
	}

	/**Removes the first value, the one that has been in there the longest, from the customers rental queue
	 * 
	 */
	public void removeRented() {
		rented.remove(0);
	}
	/**Removes a specific title from the customers rental queue
	 * 
	 * @param mediaTitle
	 */

	public void removeRented(String mediaTitle) {
		//go through the rented and if you find an element with the title the user inputs, remove it
		for (int i = 0; i < queue.size(); i++) {
			if (rented.get(i)==mediaTitle) {
				rented.remove(i);
			}
		}
	}
	/**Removes the first value, the one that has been in there the longest, from the customers wanted queue
	 * 
	 */
	public void removeQueue() {
		queue.remove(0);
	}
	/**Removes a specific title from the customers wanted queue
	 * 
	 * @param mediaTitle
	 */
	public void removeQueue(String mediaTitle) {
		//go through the queue and if you find an element with the title the user inputs, remove it
		for (int i = 0; i < queue.size(); i++) {
			if (queue.get(i)==mediaTitle) {
				queue.remove(i);
			}
		}
	}
	
	/**Checks if the customer has an equal name to another customer
	 * 
	 */
	public boolean equals(Object obj) {
		if (obj == this) {
			return true;
		}
		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		Customer customer = (Customer) obj;

		return name.equals(customer.getName());
	}
	/**Allows use of Collections.sort, checks to see if a customer is "greater than" another customer alphabetically
	 * 
	 */
	@Override
	public int compareTo(Customer otherCustomer) {
		//A's are less than Z's
		return this.getName().compareToIgnoreCase(otherCustomer.getName());
		/*
		if (this.getName().charAt(0) < otherCustomer.getName().charAt(0)) {
			return -1;	//if current name is smaller than input return negative
		} else if (this.getName().charAt(0) > otherCustomer.getName().charAt(0)) {
			return 1;	//if current name is larger return positive
		} else if (this.getName().charAt(0) == otherCustomer.getName().charAt(0)) {
			//if the first characters are the same, evaluate using the 2nd character
			if (this.getName().charAt(1) < otherCustomer.getName().charAt(1)) {
				return -1;
			} else if (this.getName().charAt(1) > otherCustomer.getName().charAt(1)) {
				return 1;
			} else if (this.getName().charAt(1) == otherCustomer.getName().charAt(1)) {
				//if even the 2nd characters are equal we give up and just deem these names as equal
				return 0;
			}
		}
		return 0;	//if both values equal return 0
		 */
	}
	/**
	 * Prints information about the customer as string
	 */
	@Override
	public String toString() {
		return "Name: "+this.name+", Address: "+this.address+", Plan: "+
				this.plan+"\nRented: "+this.rented+"\n"+"Queue: "+this.queue;
	}
	public static void main(String[] args) {
		Customer customer1 = new Customer("Ndenko","12620 Hillmeade Station Dr",
				"unlimited");
		System.out.println(customer1);
		Customer.setLimit(2);
		Customer customer2 = new Customer("Batman","Gotham", "limited");
		System.out.println(customer2);
		System.out.println(customer2.queue.toString());
		Customer customer3 = new Customer("Netero","Mountains", "limited");
		System.out.println(customer3.getPlan());
		customer3.addRented("Scary movie 1");
		customer3.addRented("Scary movie 2");
		customer3.addRented("Scary movie 3");
		System.out.println(customer3.toString());
		System.out.println(customer1.compareTo(customer2));//should return -1
		System.out.println(customer2.compareTo(customer1));//should return 1
		System.out.println(customer1.compareTo(customer1));//should return 0
		System.out.println(customer3.equals(customer2));

		//customer3.addRented("Scary movie 4");





















		/*
		//lets use method overloading so that we can take in media objects as input but also take in datatypes to create the objects as well--

		//adds rented media to end of customers rental queue, FIFO
		public void addRented(Media media) {
			rented.add(media);
		}
		//method overloading to create a movie object then add it
		//if customers plan is "limited", throw error if size> limit
		public void addRented(String title, int copiesAvailable, String rating) {
			Movie movie = new Movie(title, copiesAvailable, rating);
			rented.add(movie);
		}
		//method overloading to create an album object then add it
		public void addRented(String title, int copiesAvailable, String artist, String songs) {
			Album album = new Album(title, copiesAvailable, artist, songs);
			rented.add(album);
		}

		//removes rented media from start of customers rental queue, FIFO
		public void removeRented() {
			rented.remove(0);
		}
		//uses method overloading to remove a specific media object, not necessarily at start of rental queue
		public void removeRented(Media media) {

		}

		//adds wanted media to end of customers wanted queue, FIFO
		public void addQueue(Media media) {
			queue.add(media);
		}
		//method overloading to create a movie object then add it
		public void addQueue(String title, int copiesAvailable, String rating) {
			Movie movie = new Movie(title, copiesAvailable, rating);
			queue.add(movie);
		}
		//method overloading to create an album object then add it
		public void addQueue(String title, int copiesAvailable, String artist, String songs) {
			Album album = new Album(title, copiesAvailable, artist, songs);
			queue.add(album);
		}
		//removes wanted from start of customers wanted queue, FIFO
		public void removeQueue() {
			queue.remove(0);
		}
		//uses method overloading to remove a specific media object, not necessarily at start of media queue
		public void removeQueue(Media media) {

		}
		 */
	}

}
